/*************************************************************************
 * Copyright (c) 2011 AT&T Intellectual Property
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html
 *
 * Contributors: Details at https://graphviz.org
 *************************************************************************/

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include <dotgen/aspect.h>
#include <stdbool.h>
#include <util/list.h>
#include <util/unused.h>

typedef LIST(Agnode_t *) node_queue_t;

void acyclic(Agraph_t *);
void allocate_ranks(Agraph_t *);
/// @return 0 on success
int build_ranks(Agraph_t *, int);
void build_skeleton(Agraph_t *, Agraph_t *);
void checkLabelOrder(graph_t *g);
void class1(Agraph_t *);
void class2(Agraph_t *);
void decompose(Agraph_t *, int);
void delete_fast_edge(Agedge_t *);
void delete_fast_node(Agraph_t *, Agnode_t *);
void delete_flat_edge(Agedge_t *);
void dot_cleanup(graph_t *g);
void dot_layout(Agraph_t *g);
void dot_init_node_edge(graph_t *g);
void dot_scan_ranks(graph_t *g);
void enqueue_neighbors(node_queue_t *q, node_t *n0, int pass);
/// @return 0 on success
int expand_cluster(Agraph_t *);
Agedge_t *fast_edge(Agedge_t *);
void fast_node(Agraph_t *, Agnode_t *);
Agedge_t *find_fast_edge(Agnode_t *, Agnode_t *);
Agedge_t *find_flat_edge(Agnode_t *, Agnode_t *);
void flat_edge(Agraph_t *, Agedge_t *);
int flat_edges(Agraph_t *);
/// @return 0 on success
int install_cluster(Agraph_t *, Agnode_t *, int, node_queue_t *);
/// @return 0 on success
int install_in_rank(Agraph_t *, Agnode_t *);
void dot_compoundEdges(Agraph_t *);
Agedge_t *make_aux_edge(Agnode_t *, Agnode_t *, double, int);
void mark_clusters(Agraph_t *);
void mark_lowclusters(Agraph_t *);
bool mergeable(edge_t *e, edge_t *f);
void merge_chain(Agraph_t *, Agedge_t *, Agedge_t *, bool);
void merge_oneway(Agedge_t *, Agedge_t *);
Agedge_t *new_virtual_edge(Agnode_t *, Agnode_t *, Agedge_t *);
bool nonconstraint_edge(Agedge_t *);
void other_edge(Agedge_t *);
void rank1(graph_t *g);
int portcmp(port p0, port p1);
int ports_eq(edge_t *, edge_t *);
void rec_reset_vlists(Agraph_t *);
void rec_save_vlists(Agraph_t *);
void reverse_edge(Agedge_t *);
void safe_other_edge(Agedge_t *);
void save_vlist(Agraph_t *);
Agedge_t *virtual_edge(Agnode_t *, Agnode_t *, Agedge_t *);
Agnode_t *virtual_node(Agraph_t *);
void virtual_weight(Agedge_t *);
void zapinlist(elist *, Agedge_t *);

Agraph_t *dot_root(void *);
/// @return 0 on success
WUR int dot_concentrate(Agraph_t *);
/// @return 0 on success
int dot_mincross(Agraph_t *);
/// @return 0 on success
WUR int dot_position(Agraph_t *);
void dot_rank(Agraph_t *);
void dot_sameports(Agraph_t *);
/// @return 0 on success
int dot_splines(Agraph_t *);

#ifdef __cplusplus
}
#endif
