/**
 * @file
 * @brief API cghdr.h
 * @ingroup cgraph_utils
 */
/*************************************************************************
 * Copyright (c) 2011 AT&T Intellectual Property
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html
 *
 * Contributors: Details at https://graphviz.org
 *************************************************************************/

#include "config.h"

#include <cgraph/cghdr.h>
#include <stdlib.h>

Dict_t *agdtopen(Dtdisc_t *disc, Dtmethod_t *method) {
  return dtopen(disc, method);
}

int agdtclose(Dict_t *dict) {
  dtdisc(dict, NULL);
  if (dtclose(dict))
    return 1;
  return 0;
}

void agdtdisc(Dict_t *dict, Dtdisc_t *disc) {
  if (dtdisc(dict, NULL) != disc) {
    dtdisc(dict, disc);
  }
  /* else unchanged, disc is same as old disc */
}
/// @defgroup cgraph_utils utilities
/// @brief low level cgraph utilities
/// @ingroup cgraph
