/*************************************************************************
 * Copyright (c) 2011 AT&T Intellectual Property 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html
 *
 * Contributors: Details at https://graphviz.org
 *************************************************************************/

#pragma once

#include "smyrnadefs.h"
#include "hier.h"

    void drawtopologicalfisheye(topview * t);
    void changetopfishfocus(topview * t, float *x, float *y, int num_foci);
    void prepare_topological_fisheye(Agraph_t* g,topview * t);
