/*************************************************************************
 * Copyright (c) 2011 AT&T Intellectual Property
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html
 *
 * Contributors: Details at https://graphviz.org
 *************************************************************************/

#pragma once

#include "gui.h"
#include "tvnodes.h"

_BB void on_TVNodes_close(GtkWidget *widget, void *user_data);
_BB void btnTVOK_clicked_cb(GtkWidget *widget, void *user_data);
_BB void btnTVShowAll_clicked_cb(GtkWidget *widget, void *user_data);
_BB void btnTVHideAll_clicked_cb(GtkWidget *widget, void *user_data);

_BB void btnTVSaveAs_clicked_cb(GtkWidget *widget, void *user_data);
_BB void btnTVSaveWith_clicked_cb(GtkWidget *widget, void *user_data);
